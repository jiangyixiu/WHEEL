<template>
  <div>
    collect
  </div>
</template>

<script>
export default {
}
</script>
