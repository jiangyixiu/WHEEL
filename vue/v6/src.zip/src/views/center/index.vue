<template>
  <div>
    我的<br>
    <ul>
      <li><router-link to='/collect'>collect</router-link></li>
      <li><a href="destination.html#/search?from=center">destination index</a></li>
    </ul>
  </div>
</template>

<script>
export default {
    mounted () {
    }
}
</script>
