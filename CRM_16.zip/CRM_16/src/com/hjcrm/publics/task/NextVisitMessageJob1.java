package com.hjcrm.publics.task;

public class NextVisitMessageJob1 {
	
	public void demo09Job(){
		System.out.println("1222");
	}
	
	public void demo09Job3(){
		System.out.println("1222");
	}

}
