package com.hjcrm.publics.dao;

public class DaoConstants {

	public static final String Common_Insert = "Common_Insert";
	public static final String Common_BatchInsert = "Common_BatchInsert";
	public static final String Common_Update = "Common_Update";
	public static final String Common_BatchUpdate = "Common_BatchUpdate";
	public static final String Common_Delete = "Common_Delete";
	public static final String Common_Delete_By_Ids = "Common_Delete_By_Ids";
	public static final String Common_Select_By_Id = "Common_Select_By_Id"; 
	public static final String Common_Select = "Common_Select";
}
